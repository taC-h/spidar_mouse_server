const socket = new WebSocket(`ws://${ document.location.host }/ws/`);
socket.loger = document.getElementById("logger");

socket.addEventListener("open",(e)=>{
    socket.loger.innerHTML = "ws:conetced";
});

socket.addEventListener("message",(e)=>{
    socket.loger.innerHTML = e.data;
});

socket.addEventListener("close",(e)=>{
    socket.loger.innerHTML = "ws:closed";
});

socket.addEventListener("error",(e)=>{
    socket.loger.innerHTML = "ws:closed by error" + new String(e);
});